import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:google_sign_in/google_sign_in.dart';

void main() => runApp(const RecoverApp());

const _native = MethodChannel('com.example.recover/notifications');

class RecoverApp extends StatelessWidget {
  const RecoverApp({super.key});

  @override
  Widget build(BuildContext context) {
    const purple = Color(0xFF8B5CF6);
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'RECOVER',
      theme: ThemeData(
        brightness: Brightness.dark,
        scaffoldBackgroundColor: const Color(0xFF0B1020),
        colorScheme: ColorScheme.fromSeed(
          seedColor: purple,
          brightness: Brightness.dark,
          surface: const Color(0xFF151C30),
        ),
        useMaterial3: true,
      ),
      home: const LoginPage(),
    );
  }
}

class LoginPage extends StatefulWidget {
  const LoginPage({super.key});
  @override
  State<LoginPage> createState() => _LoginPageState();
}

class _LoginPageState extends State<LoginPage> {
  bool _busy = false;

  Future<void> _googleLogin() async {
    setState(() => _busy = true);
    try {
      // Configure OAuth/Firebase for production. This obtains the Google account
      // on supported devices; do not treat a client-side sign-in as backend auth.
      final account = await GoogleSignIn().signIn();
      if (!mounted) return;
      if (account == null) return;
      Navigator.of(context).pushReplacement(
        MaterialPageRoute(builder: (_) => HomePage(email: account.email)),
      );
    } catch (e) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text('Sign-in setup required: $e')),
        );
      }
    } finally {
      if (mounted) setState(() => _busy = false);
    }
  }

  @override
  Widget build(BuildContext context) => Scaffold(
    body: SafeArea(
      child: Center(
        child: Padding(
          padding: const EdgeInsets.all(28),
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              const Icon(Icons.shield_moon_rounded, size: 76, color: Color(0xFFB49AFF)),
              const SizedBox(height: 18),
              const Text('RECOVER', style: TextStyle(fontSize: 34, fontWeight: FontWeight.w900, letterSpacing: 3)),
              const SizedBox(height: 8),
              const Text('Your notification history, in one place', textAlign: TextAlign.center,
                  style: TextStyle(color: Colors.white70)),
              const SizedBox(height: 42),
              SizedBox(
                width: double.infinity,
                child: FilledButton.icon(
                  onPressed: _busy ? null : _googleLogin,
                  icon: const Icon(Icons.login),
                  label: Text(_busy ? 'Please wait…' : 'Continue with Google'),
                ),
              ),
              const SizedBox(height: 14),
              const Text('RECOVER only saves notifications after you grant permission.',
                  textAlign: TextAlign.center, style: TextStyle(fontSize: 12, color: Colors.white54)),
            ],
          ),
        ),
      ),
    ),
  );
}

class HomePage extends StatefulWidget {
  final String email;
  const HomePage({super.key, required this.email});
  @override
  State<HomePage> createState() => _HomePageState();
}

class _HomePageState extends State<HomePage> {
  List<Map<dynamic, dynamic>> _items = [];
  bool _supported = true;

  Future<void> _load() async {
    try {
      final rows = await _native.invokeMethod<List<dynamic>>('getNotifications');
      setState(() {
        _items = (rows ?? []).cast<Map<dynamic, dynamic>>();
        _supported = true;
      });
    } on PlatformException {
      setState(() => _supported = false);
    } on MissingPluginException {
      setState(() => _supported = false);
    }
  }

  Future<void> _enableAccess() async {
    try {
      await _native.invokeMethod('openNotificationSettings');
    } catch (_) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(content: Text('Notification capture is supported on Android only.')),
        );
      }
    }
  }

  Future<void> _clear() async {
    await _native.invokeMethod('clearNotifications');
    await _load();
  }

  @override
  void initState() {
    super.initState();
    _load();
  }

  @override
  Widget build(BuildContext context) => Scaffold(
    appBar: AppBar(
      title: const Text('RECOVER'),
      actions: [IconButton(onPressed: _load, icon: const Icon(Icons.refresh))],
    ),
    body: Padding(
      padding: const EdgeInsets.all(16),
      child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        Container(
          width: double.infinity,
          padding: const EdgeInsets.all(18),
          decoration: BoxDecoration(
            gradient: const LinearGradient(colors: [Color(0xFF6D45D8), Color(0xFF312E81)]),
            borderRadius: BorderRadius.circular(22),
          ),
          child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            const Text('Welcome back', style: TextStyle(color: Colors.white70)),
            const SizedBox(height: 5),
            Text(widget.email, style: const TextStyle(fontWeight: FontWeight.bold)),
            const SizedBox(height: 15),
            Text('${_items.length}', style: const TextStyle(fontSize: 32, fontWeight: FontWeight.w900)),
            const Text('Saved notifications'),
          ]),
        ),
        const SizedBox(height: 16),
        if (!_supported)
          const Card(child: Padding(
            padding: EdgeInsets.all(16),
            child: Text('iPhone: RECOVER works for account and history screens, but iOS does not allow apps to capture WhatsApp notifications from other apps.'),
          ))
        else
          SizedBox(width: double.infinity, child: OutlinedButton.icon(
            onPressed: _enableAccess,
            icon: const Icon(Icons.notifications_active_outlined),
            label: const Text('Enable Android notification access'),
          )),
        Row(mainAxisAlignment: MainAxisAlignment.spaceBetween, children: [
          const Text('Notification history', style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
          TextButton(onPressed: _clear, child: const Text('Clear all')),
        ]),
        Expanded(
          child: _items.isEmpty
            ? const Center(child: Text('No saved notifications yet.', style: TextStyle(color: Colors.white60)))
            : ListView.builder(
                itemCount: _items.length,
                itemBuilder: (context, index) {
                  final item = _items[index];
                  return Card(
                    child: ListTile(
                      leading: const CircleAvatar(child: Icon(Icons.chat_bubble_outline)),
                      title: Text('${item['title'] ?? 'Notification'}', maxLines: 1, overflow: TextOverflow.ellipsis),
                      subtitle: Text('${item['text'] ?? ''}', maxLines: 3, overflow: TextOverflow.ellipsis),
                      trailing: Text('${item['time'] ?? ''}', style: const TextStyle(fontSize: 10)),
                    ),
                  );
                },
              ),
        ),
        const Text('Captured content stays on this device in this starter build.',
          style: TextStyle(fontSize: 11, color: Colors.white38)),
      ]),
    ),
  );
}
