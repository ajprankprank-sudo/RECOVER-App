# RECOVER — Flutter + Android Notification Capture + Python API

This is a starter MVP scaffold for the RECOVER app.

## What works in this starter
- One Flutter codebase for Android and iOS UI.
- Google sign-in UI integration point (Firebase setup required).
- Android-only WhatsApp notification capture using Android's user-granted Notification Listener permission.
- Local notification history stored on the Android device.
- iPhone app can run the shared UI, login shell, and history screens, but iOS does not expose other apps' notifications to third-party apps. Therefore WhatsApp notification capture/deleted-message history is not available on iPhone.

## Important privacy behavior
- Capture is limited to notifications posted on the user's own Android device after the user explicitly enables Notification Access.
- The app does not read WhatsApp's private database, bypass encryption, or retrieve messages that were never present in a notification.
- This starter stores captured notification text locally on Android. It does not upload message contents to the server.
- Notifications may contain sensitive information. Add an in-app privacy notice and a clear delete-all option before release.

## Project layout
- `mobile/` Flutter app
- `backend/` Python Flask API starter

## Requirements
- Flutter SDK (stable)
- Android Studio + Android SDK
- Xcode on macOS for iOS builds
- Python 3.10+

## 1. Create the Flutter platform folders
From `mobile/` run:
```bash
flutter create . --platforms=android,ios
```
If Flutter asks to overwrite files, keep the supplied `lib/` and `pubspec.yaml`, and allow it to generate the platform folders. Then merge the Android Kotlin files and manifest entries from this starter into the generated Android project.

## 2. Install Flutter packages
```bash
cd mobile
flutter pub get
```

## 3. Android setup
Copy:
- `android/app/src/main/AndroidManifest.xml` into the generated app manifest (merge if you already have one).
- `android/app/src/main/kotlin/com/example/recover/MainActivity.kt`
- `android/app/src/main/kotlin/com/example/recover/RecoverNotificationListener.kt`

Make sure the Kotlin package path matches the `package` declaration. The generated app's namespace/applicationId should be `com.example.recover`, or update the package declarations and folder path consistently.

Build:
```bash
flutter run
```

On Android, open RECOVER > Settings > Enable notification access. Android will open system settings; the user must manually enable RECOVER. Android may show a warning because notification access can expose notification contents.

## 4. Google sign-in
Configure Firebase Authentication with Google provider, then add the platform-specific Firebase configuration:
- Android: `google-services.json`
- iOS: `GoogleService-Info.plist`

Run FlutterFire CLI to generate `firebase_options.dart`, then replace the placeholder in `lib/main.dart` with the generated initialization. Add `firebase_core` and `firebase_auth` dependencies and follow current Firebase Flutter setup instructions.

This scaffold intentionally does not include real client secrets or API keys.

## 5. Python backend
```bash
cd backend
python -m venv .venv
# Windows: .venv\\Scripts\\activate
# macOS/Linux:
source .venv/bin/activate
pip install -r requirements.txt
python app.py
```
The backend is a minimal health/status API only. Do not send notification contents to it unless you later add explicit consent, encryption, authentication, retention controls, and a privacy policy.

## 6. iOS limitation
iOS does not provide a public API for an ordinary third-party app to read WhatsApp notifications from Notification Center. RECOVER can run on iPhone for account, settings, and any manually imported/authorized data, but cannot automatically capture WhatsApp notifications or recover deleted WhatsApp messages there.

## Before public release
- Implement Firebase ID-token verification on the backend before accepting authenticated API requests.
- Add privacy policy, terms, data deletion, export, retention controls, and secure storage.
- Test Android notification behavior across Android versions and WhatsApp notification privacy settings.
- Review Apple App Store and Google Play policies.
