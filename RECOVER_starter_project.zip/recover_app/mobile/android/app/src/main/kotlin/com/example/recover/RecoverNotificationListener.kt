package com.example.recover

import android.service.notification.NotificationListenerService
import android.service.notification.StatusBarNotification
import android.app.Notification
import android.content.Context
import android.os.Build
import org.json.JSONArray
import org.json.JSONObject
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class RecoverNotificationListener : NotificationListenerService() {
    override fun onNotificationPosted(sbn: StatusBarNotification) {
        // Only capture WhatsApp notifications; never inspect other apps.
        if (sbn.packageName != "com.whatsapp" && sbn.packageName != "com.whatsapp.w4b") return

        val extras = sbn.notification.extras ?: return
        val title = extras.getCharSequence(Notification.EXTRA_TITLE)?.toString().orEmpty()
        val text = extras.getCharSequence(Notification.EXTRA_BIG_TEXT)?.toString()
            ?: extras.getCharSequence(Notification.EXTRA_TEXT)?.toString().orEmpty()

        // Skip empty/hidden notification previews.
        if (title.isBlank() && text.isBlank()) return

        val prefs = getSharedPreferences("recover_notifications", Context.MODE_PRIVATE)
        val old = try { JSONArray(prefs.getString("items", "[]") ?: "[]") } catch (_: Exception) { JSONArray() }
        val row = JSONObject().apply {
            put("title", title.take(160))
            put("text", text.take(2000))
            put("time", SimpleDateFormat("dd MMM, HH:mm", Locale.getDefault()).format(Date(sbn.postTime)))
        }
        val updated = JSONArray()
        // Keep most recent 500 records to limit local storage.
        val start = (old.length() - 499).coerceAtLeast(0)
        for (i in start until old.length()) updated.put(old.getJSONObject(i))
        updated.put(row)
        prefs.edit().putString("items", updated.toString()).apply()
    }
}
