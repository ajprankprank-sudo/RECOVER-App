package com.example.recover

import android.content.Intent
import android.provider.Settings
import android.content.ComponentName
import android.content.Context
import io.flutter.embedding.android.FlutterActivity
import io.flutter.embedding.engine.FlutterEngine
import io.flutter.plugin.common.MethodChannel
import org.json.JSONArray

class MainActivity : FlutterActivity() {
    private val channelName = "com.example.recover/notifications"
    private val prefsName = "recover_notifications"

    override fun configureFlutterEngine(flutterEngine: FlutterEngine) {
        super.configureFlutterEngine(flutterEngine)
        MethodChannel(flutterEngine.dartExecutor.binaryMessenger, channelName)
            .setMethodCallHandler { call, result ->
                when (call.method) {
                    "openNotificationSettings" -> {
                        startActivity(Intent(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS))
                        result.success(true)
                    }
                    "getNotifications" -> {
                        val prefs = getSharedPreferences(prefsName, Context.MODE_PRIVATE)
                        val raw = prefs.getString("items", "[]") ?: "[]"
                        val array = JSONArray(raw)
                        val list = mutableListOf<Map<String, String>>()
                        for (i in 0 until array.length()) {
                            val obj = array.getJSONObject(i)
                            list.add(mapOf(
                                "title" to obj.optString("title"),
                                "text" to obj.optString("text"),
                                "time" to obj.optString("time")
                            ))
                        }
                        result.success(list)
                    }
                    "clearNotifications" -> {
                        getSharedPreferences(prefsName, Context.MODE_PRIVATE)
                            .edit().putString("items", "[]").apply()
                        result.success(true)
                    }
                    else -> result.notImplemented()
                }
            }
    }
}
